import React from "react";
import './App.csss';
import { Container } from "react-bootstrap";

import {Route, Switch} from 'react-router-dom';
import { BrowserRouter } from "react-router-dom";
import ExpenseTRacker from "./expense-tracker";
import ShowList from "./ShowList";

const App = () => {
    return(
        <>
        <Container>
       <Switch>
          <Route path="/add" component={ExpenseTRacker} />
          <Route path="/" component={ShowList} />
        </Switch> 
        </Container>
        </>
       
    );
};

export default App;