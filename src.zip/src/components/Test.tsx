function Test () {
    const sta = ["sdd","fds","erw"]
    return(
        <>
        {
            sta && (
                sta.map(
                    ab =>(
                        <div>{ab}</div>
                    )
                )
            )
        }
        </>
    )
}

export default Test