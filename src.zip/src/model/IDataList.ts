export default interface IDataList {
    id : number,
    payeeName:string,
    product:string,
    price:number,
    setDate:string
};